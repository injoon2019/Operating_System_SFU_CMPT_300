#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char* argv[])
{
	int seed,status;
	printf("Enter the seed for the parent process\n");	//step a
	scanf("%d",&seed);	//step a
	srand(seed); //step b
	int children_process_num = rand()%5 + 5; // step b to make 5<=number of process <=9
	int grand_parent_pid = (int)getpid(); //step c
	printf("My process ID is %d\n", (int)getpid()); //step d
	int int_parent_pid = 9999;   //ERROR...
	for(int i=0;i<children_process_num;i++) //step f
	{
		printf("%d is about to create a child\n", grand_parent_pid); //step e
		pid_t parent_pid = fork();
		if(parent_pid !=0)
		{

			printf("ParentId %d has created a child with process ID %d\n",grand_parent_pid, (int)parent_pid); //step g
			printf("I am the parent, I am wating for child %d to terminate\n",(int)parent_pid); //step h_1
			
	
			pid_t parent_pid2;
			while( (parent_pid2=waitpid(parent_pid, &status, WNOHANG)) <=0 )
			{
				if(WIFEXITED(status))
					break;
			} 
			printf("I am process %d. My child%d is dead\n", grand_parent_pid,(int)parent_pid); //step h_2
			continue;

			if (i==children_process_num -1)  //if last children
			{
				while( (parent_pid2=waitpid(parent_pid, &status, WNOHANG)) <=0 )
				{
					if(WIFEXITED(status))
						break;
				} 
				printf("I am the parent, child %d has terminated\n", (int)parent_pid);  //step h_3
				sleep(5);	//step h_4
				return 0; //step h_5
			}
		}
		else if(parent_pid==0)
		{
			int_parent_pid = (int)getpid();
			if (i!=0)
			{
				seed++; //step 2_a
			}
			break;
		}
	}
	srand(seed);	//2_b
	printf("I am a new child, my process ID is %d, my seed id %d",(int)getpid(), seed); //step 2_c
	int grand_children_process_num = rand() %3 +1;  //step 2_d
	printf("I am child %d, I will have %d grand children\n", (int)getpid(), grand_children_process_num); //step2_e
	for(int i=0; i<grand_children_process_num; i++)
	{
		printf("I am child %d, I am about to create a child\n", (int)getpid()); //step 2_f
		pid_t grandchild_pid = fork();  //step 2_g
		pid_t grandchild_pid2;
		if(grandchild_pid >0)
		{
			printf("I am %d, I just created a child\n", (int)getpid() ); //step 2_h
			if( i ==grand_children_process_num-1)
			{
				printf("I am the child %d, I have %d children\n", (int)getpid(), grand_children_process_num); //step 2_i
				printf("I am wating for my children to terminate\n");	//step 2_i_2
				//
				while( (grandchild_pid2=waitpid(grandchild_pid, &status, WNOHANG)) <=0 )
				{
					if(WIFEXITED(status))
						break;
				} 
				printf("I am child %d. My child %d has been waited\n", (int)getpid(), (int)grandchild_pid);
			}
		}
		else if (grandchild_pid==0)
		{
			break;
		}
	}
	printf("I am grandchild %d, My grandparent is %d, My Parent is %d\n", (int)getpid(), (int)grand_parent_pid, int_parent_pid ); //step3_a
	int random3 = rand()%10+5; //step 3_b
	sleep(random3); //step 3_c
	printf("I am grandchild %d with parent %d, I am about to terminate\n", (int)getpid(), int_parent_pid);  //step 3_d
	exit(0);

}